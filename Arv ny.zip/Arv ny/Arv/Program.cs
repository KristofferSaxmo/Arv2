﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arv
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Ange en höjd");
            int height = int.Parse(Console.ReadLine());

            Console.WriteLine("Ange en bredd");
            int width = int.Parse(Console.ReadLine());
            Rectangle rectangle = new Rectangle(height, width);
            Triangle triangle = new Triangle(height, width);
            Console.WriteLine("Rektangelns area: " + rectangle.RecArea());
            Console.WriteLine("Rektangelns omkrets: " + rectangle.RecCircumferance());
            Console.WriteLine("");
            Console.WriteLine("Triangelns area: " + triangle.TriArea());
            Console.WriteLine("Triangelns omkrets: " + triangle.TriCircumferance());
            Console.ReadLine();
        }
    }
}
